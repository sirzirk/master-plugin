<?php

//Silence is golden.